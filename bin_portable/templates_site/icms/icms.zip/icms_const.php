<?php

$StringTemplateTypeID = array('Audio', 'GameCube', 'Movie', 'NintendoDS', 'PCGames', 'PlayStation2', 'PlayStation3', 'PlayStationPortable', 'Software', 'Wii', 'Xbox', 'Xbox360', 'XXX');

$StringComponentID = array('IReleaseName', 'ITitle', 'IPicture', 'INotes', 'IPassword', 'IAudioBitrate', 'IAudioEncoder', 'IAudioSamplingRate', 'IAudioStream', 'IGenre', 'ILanguage', 'IVideoCodec', 'IVideoStream', 'IVideoSystem', 'INFO', 'IDescription');

?>