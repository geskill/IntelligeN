IntelligeN Content management system (ICMS)

EN/ENG:
Since IntelligeN cannot implement every single and small cms,
you can use and modify this cms for your own needs.

DE/DEU:
Da IntelligeN nicht jedes einzelne CMS unterst�tzen kann,
wurde mit dem ICMS eine M�glichkeit geschaffen auch kleinere
CMS nachzur�sten. Ver�ndern Sie den Quellcode einfach an den
markieren Stellen.