<?php
require_once('icms_const.php');
require_once('icms_utils.php');

/* TODO: YOUR CODE HERE */
/* 
	- CONNECT TO DATABASE
	- CHECK USER RIGHTS TO ADD/CHANGE/REMOVE THE ENTRY
	- USE "xmlresult(true);" TO RETURN SUCCESS
*/

function AddEntry($type, $subject, $values, $directlinks, $crypterlinks, $use_account, $account_username, $account_password)
{
	xmlresult(true);
}

?>